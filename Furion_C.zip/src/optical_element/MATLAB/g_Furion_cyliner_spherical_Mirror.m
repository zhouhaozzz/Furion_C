classdef g_Furion_cyliner_spherical_Mirror<g_oe
    %Furion_cylinder_spherical          >>> common approach <<<
%( X,Y,Phi,Psi,ds,di,chi,theta,r,n )
%all rotation angle is left-hand 
% coordinate column vector  -->   (x,y,z);
%row vector X Y Phi Psi;
%************************************************************************
% ID:     Furion_21070902
% ***********************************************************************
% Input:  Position X Y ;direction Phi Psi;source distance ds;image
% distance di;rotation angle chi(0 90 180 270) z_directiion
% right-hand;incident angle respect to the surface theta;the total number
% of the light rays n;
% ***********************************************************************
% Ouput:  Position X Y  and direction Phi Psi
% ***********************************************************************
%
% Modification history
%   2021-7-9 create add annotation debug ;
%   2021-7-9 add trace interface ;
%   2021-9-20 change function to class
%************************************************************************
 properties
       r;%Բ���澵�����ʰ뾶
 end
 methods  
    function obj = g_Furion_cyliner_spherical_Mirror( beam_in,ds,di,chi,theta,surface,r,grating)    
       obj=obj@g_oe( beam_in,ds,di,chi,theta,surface,grating) ; %��ʼ������
       obj.r=r;%��ʼ���뾶
       obj.reflect(beam_in,ds,di,chi,theta) ;
end
 end
 
 methods%�ڹ�ѧƽ������ϵ�У�Բ���澵�ķ��߷���
    function [Nx,Ny,Nz]=normal(obj)
       Ny=-(obj.Y2-obj.r)/obj.r; 
       Nz=-obj.Z2/obj.r;  
       Nx = 0*Ny;
    end
 end

 methods %�󽻵�
        function [X2,Y2,Z2,T]=intersection(obj)
            r1=obj.r;
            %L1=obj.L1;N1=obj.N1;M1=obj.M1;Y1=obj.Y1;Z1=obj.Z1;X1=obj.X1;
            %r=obj.r;
            A=obj.N1.^2+obj.M1.^2;%����һԪ���η���2����ϵ��
            B=2.*(obj.N1.*obj.Z1+obj.Y1.*obj.M1-r1.*obj.M1);%����һԪ���η���һ����ϵ��
            C=obj.Y1.^2+obj.Z1.^2-2*r1.*obj.Y1;%����һԪ���η��̳�����ϵ��
            T=(-B+(B.^2-4*A.*C).^0.5)./(2*A);%һԪ���η��̵Ľ�����
            X2= obj.X1+T.*obj.L1;     
            Y2= obj.Y1+T.*obj.M1;   
            Z2= obj.Z1+T.*obj.N1;   
        end
 end
 
end
