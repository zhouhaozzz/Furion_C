#include "grating.h"

using namespace Furion_NS;

Grating::Grating(double n0, double b, double m, double lambda_G) : n0(n0), b(b), m(m), lambda_G(lambda_G)
{

}

Grating::~Grating()
{

}