%%
F0([0,1e10],100).compound_F('H_2 O').plot_f('H_2O'); %F0                                                                                              
%%
F1F2([10,30000],10000,'N').plot_f1();                %F1F2
%% 
